# karmabot-serverless
Karma Slack bot, made with serverless. See https://www.sentialabs.io/2018/08/16/Building-a-Slackbot-with-Serverless-Framework.html

Setting up your environment:
Check if you already registered your local environment ssh key at github.
Clone this repo into your local machine
Install serverless # Installing the serverless cli
npm install -g serverless
